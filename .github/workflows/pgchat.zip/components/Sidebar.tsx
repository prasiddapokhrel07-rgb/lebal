
import React from 'react';
import { ChatSession } from '../types';

interface SidebarProps {
  sessions: ChatSession[];
  currentSessionId: string | null;
  onSelectSession: (id: string) => void;
  onNewChat: () => void;
  onDeleteSession: (id: string, e: React.MouseEvent) => void;
}

const Sidebar: React.FC<SidebarProps> = ({
  sessions,
  currentSessionId,
  onSelectSession,
  onNewChat,
  onDeleteSession,
}) => {
  return (
    <div className="w-64 h-full bg-[#1e293b] flex flex-col border-r border-slate-700">
      <div className="p-4">
        <button
          onClick={onNewChat}
          className="w-full flex items-center justify-center gap-2 px-4 py-3 bg-blue-600 hover:bg-blue-700 text-white rounded-lg transition-colors font-medium shadow-lg"
        >
          <i className="fa-solid fa-plus"></i>
          New Chat
        </button>
      </div>

      <div className="flex-1 overflow-y-auto custom-scrollbar px-2 space-y-1">
        <div className="px-2 pt-2 pb-1 text-xs font-semibold text-slate-500 uppercase tracking-wider">
          Recent Chats
        </div>
        {sessions.length === 0 ? (
          <div className="px-3 py-4 text-sm text-slate-400 italic">
            No chats yet...
          </div>
        ) : (
          sessions
            .sort((a, b) => b.updatedAt - a.updatedAt)
            .map((session) => (
              <div
                key={session.id}
                onClick={() => onSelectSession(session.id)}
                className={`group relative flex items-center gap-3 px-3 py-3 rounded-lg cursor-pointer transition-all ${
                  currentSessionId === session.id
                    ? 'bg-slate-700 text-white shadow-md'
                    : 'text-slate-400 hover:bg-slate-800 hover:text-slate-200'
                }`}
              >
                <i className={`fa-regular ${currentSessionId === session.id ? 'fa-message' : 'fa-comment'} text-sm`}></i>
                <span className="flex-1 truncate text-sm font-medium">
                  {session.title}
                </span>
                <button
                  onClick={(e) => onDeleteSession(session.id, e)}
                  className="opacity-0 group-hover:opacity-100 p-1 hover:text-red-400 transition-opacity"
                >
                  <i className="fa-solid fa-trash-can text-xs"></i>
                </button>
              </div>
            ))
        )}
      </div>

      <div className="p-4 border-t border-slate-700">
        <div className="flex items-center gap-3 px-2">
          <div className="w-8 h-8 rounded-full bg-gradient-to-tr from-blue-500 to-purple-500 flex items-center justify-center text-white font-bold text-xs">
            PG
          </div>
          <div className="flex-1 min-w-0">
            <p className="text-sm font-medium text-slate-200 truncate">pgchat User</p>
            <p className="text-xs text-slate-500 truncate">Pro Plan</p>
          </div>
          <button className="text-slate-400 hover:text-white transition-colors">
            <i className="fa-solid fa-gear"></i>
          </button>
        </div>
      </div>
    </div>
  );
};

export default Sidebar;
