
import React, { useState, useRef, useEffect } from 'react';

interface ChatInputProps {
  onSend: (message: string) => void;
  isLoading: boolean;
}

const ChatInput: React.FC<ChatInputProps> = ({ onSend, isLoading }) => {
  const [input, setInput] = useState('');
  const textareaRef = useRef<HTMLTextAreaElement>(null);

  const handleSend = () => {
    if (input.trim() && !isLoading) {
      onSend(input);
      setInput('');
    }
  };

  useEffect(() => {
    if (textareaRef.current) {
      textareaRef.current.style.height = 'auto';
      textareaRef.current.style.height = `${Math.min(textareaRef.current.scrollHeight, 200)}px`;
    }
  }, [input]);

  const handleKeyDown = (e: React.KeyboardEvent) => {
    if (e.key === 'Enter' && !e.shiftKey) {
      e.preventDefault();
      handleSend();
    }
  };

  return (
    <div className="relative group max-w-4xl mx-auto w-full px-4 mb-4">
      <div className="relative flex items-end w-full bg-slate-800 border border-slate-700 rounded-2xl shadow-2xl overflow-hidden focus-within:border-blue-500 transition-colors">
        <textarea
          ref={textareaRef}
          rows={1}
          value={input}
          onChange={(e) => setInput(e.target.value)}
          onKeyDown={handleKeyDown}
          placeholder="Ask anything..."
          className="w-full bg-transparent text-slate-200 py-4 pl-6 pr-14 resize-none focus:outline-none custom-scrollbar text-base"
          style={{ minHeight: '60px' }}
        />
        <button
          onClick={handleSend}
          disabled={!input.trim() || isLoading}
          className={`absolute right-3 bottom-3 w-10 h-10 flex items-center justify-center rounded-xl transition-all ${
            input.trim() && !isLoading
              ? 'bg-blue-600 text-white hover:bg-blue-500 scale-100 shadow-lg'
              : 'bg-slate-700 text-slate-500 scale-90 cursor-not-allowed'
          }`}
        >
          {isLoading ? (
            <div className="w-4 h-4 border-2 border-white/30 border-t-white rounded-full animate-spin"></div>
          ) : (
            <i className="fa-solid fa-arrow-up"></i>
          )}
        </button>
      </div>
      <p className="text-[10px] text-center text-slate-500 mt-2 px-4">
        pgchat may display inaccurate info. Always double-check important results.
      </p>
    </div>
  );
};

export default ChatInput;
