
import React from 'react';
import { Message, Role } from '../types';

interface MessageBubbleProps {
  message: Message;
}

const MessageBubble: React.FC<MessageBubbleProps> = ({ message }) => {
  const isUser = message.role === Role.USER;

  // Simple Markdown parser for highlights and code blocks
  const formatContent = (text: string) => {
    return text.split('\n').map((line, i) => {
      // Code blocks (very basic detection)
      if (line.startsWith('```')) return null;
      
      // Inline code
      let formattedLine = line.replace(/`([^`]+)`/g, '<code class="bg-slate-700 px-1.5 py-0.5 rounded text-blue-300 text-sm">$1</code>');
      
      // Bold
      formattedLine = formattedLine.replace(/\*\*([^*]+)\*\*/g, '<strong class="font-bold text-slate-100">$1</strong>');

      return <p key={i} className="mb-3 leading-relaxed" dangerouslySetInnerHTML={{ __html: formattedLine }} />;
    });
  };

  return (
    <div className={`w-full flex ${isUser ? 'justify-end' : 'justify-start'} mb-6 px-4 animate-in fade-in slide-in-from-bottom-2 duration-300`}>
      <div className={`flex max-w-[85%] ${isUser ? 'flex-row-reverse' : 'flex-row'} gap-3`}>
        <div className={`flex-shrink-0 w-8 h-8 rounded-lg flex items-center justify-center text-sm font-bold shadow-sm ${
          isUser 
            ? 'bg-blue-600 text-white' 
            : 'bg-slate-700 text-blue-400'
        }`}>
          {isUser ? 'U' : <i className="fa-solid fa-sparkles text-xs"></i>}
        </div>
        
        <div className={`flex flex-col ${isUser ? 'items-end' : 'items-start'}`}>
          <div className={`px-5 py-4 rounded-2xl text-slate-200 shadow-sm ${
            isUser 
              ? 'bg-slate-700 rounded-tr-none' 
              : 'bg-slate-800/50 border border-slate-700/50 rounded-tl-none'
          }`}>
            <div className="text-sm whitespace-pre-wrap break-words">
              {formatContent(message.content)}
              {message.isStreaming && <span className="inline-block w-1.5 h-4 bg-blue-500 animate-pulse ml-1 align-middle"></span>}
            </div>

            {!isUser && message.groundingSources && message.groundingSources.length > 0 && (
              <div className="mt-4 pt-3 border-t border-slate-700/50 space-y-2">
                <p className="text-[10px] uppercase font-bold text-slate-500 tracking-wider">Sources</p>
                <div className="flex flex-wrap gap-2">
                  {message.groundingSources.slice(0, 3).map((source, idx) => (
                    <a
                      key={idx}
                      href={source.uri}
                      target="_blank"
                      rel="noopener noreferrer"
                      className="text-[11px] flex items-center gap-1.5 bg-slate-900/50 hover:bg-slate-900 border border-slate-700 px-2 py-1 rounded-md text-blue-400 transition-colors"
                    >
                      <i className="fa-solid fa-link text-[10px]"></i>
                      <span className="max-w-[120px] truncate">{source.title}</span>
                    </a>
                  ))}
                </div>
              </div>
            )}
          </div>
          <span className="text-[10px] text-slate-500 mt-1.5 px-1 uppercase tracking-tighter">
            {new Date(message.timestamp).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}
          </span>
        </div>
      </div>
    </div>
  );
};

export default MessageBubble;
