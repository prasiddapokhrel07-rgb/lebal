
import React, { useState, useEffect, useCallback, useRef } from 'react';
import { v4 as uuidv4 } from 'uuid';
import Sidebar from './components/Sidebar';
import ChatInput from './components/ChatInput';
import MessageBubble from './components/MessageBubble';
import { ChatSession, Message, Role } from './types';
import { sendMessageStream, generateTitle } from './services/geminiService';

const App: React.FC = () => {
  const [sessions, setSessions] = useState<ChatSession[]>([]);
  const [currentSessionId, setCurrentSessionId] = useState<string | null>(null);
  const [isLoading, setIsLoading] = useState(false);
  const [isSidebarOpen, setIsSidebarOpen] = useState(true);
  const scrollRef = useRef<HTMLDivElement>(null);

  // Load data from local storage on mount
  useEffect(() => {
    const saved = localStorage.getItem('gemini_chats');
    if (saved) {
      try {
        const parsed = JSON.parse(saved);
        setSessions(parsed);
        if (parsed.length > 0) {
          setCurrentSessionId(parsed[0].id);
        }
      } catch (e) {
        console.error("Failed to load history", e);
      }
    }
  }, []);

  // Persist sessions to local storage
  useEffect(() => {
    localStorage.setItem('gemini_chats', JSON.stringify(sessions));
  }, [sessions]);

  // Scroll to bottom when messages change
  useEffect(() => {
    if (scrollRef.current) {
      scrollRef.current.scrollTop = scrollRef.current.scrollHeight;
    }
  }, [sessions, currentSessionId]);

  const currentSession = sessions.find(s => s.id === currentSessionId);

  const handleNewChat = useCallback(() => {
    const newId = uuidv4();
    const newSession: ChatSession = {
      id: newId,
      title: 'New Chat',
      messages: [],
      updatedAt: Date.now(),
    };
    setSessions(prev => [newSession, ...prev]);
    setCurrentSessionId(newId);
  }, []);

  const handleDeleteSession = useCallback((id: string, e: React.MouseEvent) => {
    e.stopPropagation();
    setSessions(prev => prev.filter(s => s.id !== id));
    if (currentSessionId === id) {
      setCurrentSessionId(null);
    }
  }, [currentSessionId]);

  const handleSendMessage = async (text: string) => {
    let activeSessionId = currentSessionId;
    
    // Create new session if none active
    if (!activeSessionId) {
      const newId = uuidv4();
      const newSession: ChatSession = {
        id: newId,
        title: 'New Chat',
        messages: [],
        updatedAt: Date.now(),
      };
      setSessions(prev => [newSession, ...prev]);
      activeSessionId = newId;
      setCurrentSessionId(newId);
    }

    const userMessage: Message = {
      id: uuidv4(),
      role: Role.USER,
      content: text,
      timestamp: Date.now(),
    };

    // Optimistically add user message
    setSessions(prev => prev.map(s => 
      s.id === activeSessionId 
        ? { ...s, messages: [...s.messages, userMessage], updatedAt: Date.now() } 
        : s
    ));

    setIsLoading(true);

    // Initial bot message for streaming
    const botMessageId = uuidv4();
    const botPlaceholder: Message = {
      id: botMessageId,
      role: Role.MODEL,
      content: "",
      timestamp: Date.now(),
      isStreaming: true
    };

    setSessions(prev => prev.map(s => 
      s.id === activeSessionId 
        ? { ...s, messages: [...s.messages, botPlaceholder] } 
        : s
    ));

    try {
      const currentMessages = sessions.find(s => s.id === activeSessionId)?.messages || [];
      const stream = sendMessageStream(currentMessages, text);
      
      let finalContent = "";
      let groundingSources = undefined;

      for await (const chunk of stream) {
        finalContent = chunk.text;
        groundingSources = chunk.groundingSources;
        
        setSessions(prev => prev.map(s => 
          s.id === activeSessionId 
            ? { 
                ...s, 
                messages: s.messages.map(m => 
                  m.id === botMessageId ? { ...m, content: finalContent, groundingSources } : m
                ) 
              } 
            : s
        ));
      }

      // Mark streaming as complete
      setSessions(prev => prev.map(s => 
        s.id === activeSessionId 
          ? { 
              ...s, 
              messages: s.messages.map(m => 
                m.id === botMessageId ? { ...m, isStreaming: false } : m
              ) 
            } 
          : s
      ));

      // Auto-generate title for first message
      if (currentMessages.length === 0) {
        const newTitle = await generateTitle(text);
        setSessions(prev => prev.map(s => 
          s.id === activeSessionId ? { ...s, title: newTitle } : s
        ));
      }

    } catch (error) {
      console.error("Chat error", error);
      setSessions(prev => prev.map(s => 
        s.id === activeSessionId 
          ? { 
              ...s, 
              messages: s.messages.map(m => 
                m.id === botMessageId ? { ...m, content: "Sorry, I encountered an error. Please check your API key and try again.", isStreaming: false } : m
              ) 
            } 
          : s
      ));
    } finally {
      setIsLoading(false);
    }
  };

  return (
    <div className="flex h-screen w-full bg-[#0f172a] text-slate-200 overflow-hidden">
      {/* Mobile Toggle */}
      <button 
        onClick={() => setIsSidebarOpen(!isSidebarOpen)}
        className="fixed top-4 left-4 z-50 md:hidden bg-slate-800 p-2 rounded-lg text-slate-400 hover:text-white"
      >
        <i className={`fa-solid ${isSidebarOpen ? 'fa-xmark' : 'fa-bars'}`}></i>
      </button>

      {/* Sidebar */}
      <div className={`${isSidebarOpen ? 'translate-x-0' : '-translate-x-full'} md:translate-x-0 transition-transform duration-300 fixed md:static inset-y-0 left-0 z-40`}>
        <Sidebar 
          sessions={sessions}
          currentSessionId={currentSessionId}
          onSelectSession={(id) => {
            setCurrentSessionId(id);
            if (window.innerWidth < 768) setIsSidebarOpen(false);
          }}
          onNewChat={handleNewChat}
          onDeleteSession={handleDeleteSession}
        />
      </div>

      {/* Overlay for mobile */}
      {isSidebarOpen && (
        <div 
          className="md:hidden fixed inset-0 bg-black/50 z-30"
          onClick={() => setIsSidebarOpen(false)}
        />
      )}

      {/* Main Content Area */}
      <main className="flex-1 flex flex-col h-full relative">
        <header className="h-16 border-b border-slate-800 flex items-center justify-between px-6 bg-[#0f172a]/80 backdrop-blur-md sticky top-0 z-20">
          <div className="flex items-center gap-2">
            <span className="text-sm font-semibold text-slate-400">pgchat</span>
            <span className="text-[10px] bg-blue-600/20 text-blue-400 px-1.5 py-0.5 rounded font-bold uppercase tracking-widest">v1.0</span>
          </div>
          <div className="flex items-center gap-4">
            <button className="text-slate-400 hover:text-white text-sm">
              <i className="fa-solid fa-share-nodes mr-2"></i>
              Share
            </button>
            <div className="w-8 h-8 rounded-full bg-slate-800 flex items-center justify-center cursor-pointer hover:bg-slate-700 transition-colors">
               <i className="fa-regular fa-user text-xs"></i>
            </div>
          </div>
        </header>

        <div 
          ref={scrollRef}
          className="flex-1 overflow-y-auto custom-scrollbar flex flex-col pt-4"
        >
          {!currentSession || currentSession.messages.length === 0 ? (
            <div className="flex-1 flex flex-col items-center justify-center p-8 text-center max-w-2xl mx-auto space-y-6">
              <div className="w-20 h-20 rounded-3xl bg-gradient-to-br from-blue-600 to-indigo-700 flex items-center justify-center text-white text-4xl shadow-2xl shadow-blue-500/20 mb-4 animate-bounce">
                <i className="fa-solid fa-sparkles"></i>
              </div>
              <h1 className="text-3xl font-bold text-white tracking-tight">How can I help you today?</h1>
              <p className="text-slate-400 leading-relaxed text-lg">
                I'm <strong>pgchat</strong>, your high-performance assistant. Ask me to write code, explain concepts, 
                generate summaries, or just have a chat.
              </p>
              
              <div className="grid grid-cols-1 md:grid-cols-2 gap-3 w-full mt-10">
                {[
                  "Write a Python script to scrape news",
                  "Explain quantum entanglement simply",
                  "Help me debug a React hook",
                  "Summarize the latest AI trends"
                ].map((prompt) => (
                  <button
                    key={prompt}
                    onClick={() => handleSendMessage(prompt)}
                    className="p-4 bg-slate-800/40 hover:bg-slate-800 border border-slate-700/50 rounded-xl text-left text-sm text-slate-300 transition-all hover:border-blue-500/50 group"
                  >
                    <span className="block font-medium group-hover:text-blue-400 transition-colors">"{prompt}"</span>
                  </button>
                ))}
              </div>
            </div>
          ) : (
            <div className="max-w-4xl mx-auto w-full pb-32">
              {currentSession.messages.map((msg) => (
                <MessageBubble key={msg.id} message={msg} />
              ))}
              {isLoading && !currentSession.messages[currentSession.messages.length - 1].isStreaming && (
                 <div className="px-8 py-4">
                    <div className="flex gap-4">
                      <div className="w-8 h-8 rounded-lg bg-slate-700 flex items-center justify-center">
                        <i className="fa-solid fa-sparkles text-blue-400 animate-pulse"></i>
                      </div>
                      <div className="flex space-x-1 items-center mt-2">
                        <div className="w-2 h-2 bg-slate-600 rounded-full animate-bounce [animation-delay:-0.3s]"></div>
                        <div className="w-2 h-2 bg-slate-600 rounded-full animate-bounce [animation-delay:-0.15s]"></div>
                        <div className="w-2 h-2 bg-slate-600 rounded-full animate-bounce"></div>
                      </div>
                    </div>
                 </div>
              )}
            </div>
          )}
        </div>

        {/* Input Area */}
        <div className="absolute bottom-0 left-0 right-0 bg-gradient-to-t from-[#0f172a] via-[#0f172a] to-transparent pt-10 pb-4">
          <ChatInput onSend={handleSendMessage} isLoading={isLoading} />
        </div>
      </main>
    </div>
  );
};

export default App;
