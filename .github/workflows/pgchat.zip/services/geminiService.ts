
import { GoogleGenAI, GenerateContentResponse } from "@google/genai";
import { Message, Role, GroundingSource } from "../types";

const ai = new GoogleGenAI({ apiKey: process.env.API_KEY || "" });

const MODEL_NAME = 'gemini-3-flash-preview';

export async function* sendMessageStream(
  history: Message[],
  message: string,
  useSearch: boolean = true
) {
  const chat = ai.chats.create({
    model: MODEL_NAME,
    config: {
      systemInstruction: "You are a helpful, advanced AI assistant. Provide concise yet thorough answers. Use Markdown for formatting. If you use code, specify the language.",
      tools: useSearch ? [{ googleSearch: {} }] : [],
    },
  });

  // Prepare history for the chat API
  // Note: The chat object manages history internally if we just call sendMessage, 
  // but to maintain state across refreshes, we can pass existing messages.
  // For simplicity in this demo, we'll send the user message to a fresh chat instance 
  // with context prepended or use the chat history property.
  
  const stream = await chat.sendMessageStream({ message });
  
  let fullText = "";
  let groundingSources: GroundingSource[] = [];

  for await (const chunk of stream) {
    const c = chunk as GenerateContentResponse;
    const text = c.text || "";
    fullText += text;

    // Extract grounding sources if available
    const chunks = c.candidates?.[0]?.groundingMetadata?.groundingChunks;
    if (chunks) {
      chunks.forEach((chunk: any) => {
        if (chunk.web) {
          groundingSources.push({
            title: chunk.web.title,
            uri: chunk.web.uri
          });
        }
      });
    }

    yield {
      text: fullText,
      groundingSources: groundingSources.length > 0 ? groundingSources : undefined
    };
  }
}

export async function generateTitle(firstMessage: string): Promise<string> {
  try {
    const response = await ai.models.generateContent({
      model: MODEL_NAME,
      contents: `Generate a very short, 2-4 word title for a chat that starts with this message: "${firstMessage}". Return only the title text, nothing else.`,
    });
    return response.text.replace(/["']/g, "").trim() || "New Chat";
  } catch (error) {
    console.error("Title generation failed", error);
    return "New Chat";
  }
}
